package edu.montana.csci.csci468.demo;

import java.util.Objects;

public class BytecodeDemo {

    boolean comp(Object a, Object b){
        return Objects.equals(a,b);
    }

}
